# =============================================================================
# Скрипт автоматического переноса компьютера из домена cds.can в ukpomosch.local
# =============================================================================

# Проверка прав администратора (попытка выполнить админскую команду)
Write-Host "Checking permissions..." -ForegroundColor Cyan
try {
    # Пробуем выполнить админскую команду
    $null = Get-LocalUser -ErrorAction Stop | Select-Object -First 1
    Write-Host "Permission check: OK" -ForegroundColor Green
}
catch {
    Write-Host "`n========================================" -ForegroundColor Red
    Write-Host "ERROR: Insufficient privileges!" -ForegroundColor Red
    Write-Host "========================================`n" -ForegroundColor Red
    Write-Host "This script requires LOCAL ADMINISTRATOR privileges.`n" -ForegroundColor Yellow

    Write-Host "Current user: $env:USERNAME" -ForegroundColor Gray
    Write-Host "Current domain: $env:USERDOMAIN`n" -ForegroundColor Gray
    Write-Host "Error: $_`n" -ForegroundColor Yellow

    Write-Host "Solutions:" -ForegroundColor Yellow
    Write-Host "  1. Run START_MIGRATION.bat (uses domain admin credentials)" -ForegroundColor Gray
    Write-Host "  2. Run PowerShell as Administrator manually`n" -ForegroundColor Gray

    Write-Host "Press any key to exit..." -ForegroundColor Yellow
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

# =============================================================================
# КОНФИГУРАЦИЯ (настройте перед использованием!)
# =============================================================================

$OLD_DOMAIN = "cds.can"
$OLD_DOMAIN_ADMIN_USER = "dh-it-011"  # Админ старого домена (без домена)

$NEW_DOMAIN = "ukpomosch.local"
$NEW_DOMAIN_USER = "ukpomosch.local\chaikin_aa"  # Служебная учетка для миграции (Domain Admin)
$NEW_DOMAIN_DC = "192.168.0.200"  # IP контроллера домена для LDAP проверок
$NEW_DNS_PRIMARY = "192.168.0.3"      # Первый DNS сервер нового домена
$NEW_DNS_SECONDARY = "192.168.0.11"   # Второй DNS сервер нового домена

# =============================================================================
# ЗАШИФРОВАННЫЙ ПАРОЛЬ (для безопасности)
# =============================================================================
# Ключ шифрования (НЕ ИЗМЕНЯТЬ! Используется обоими скриптами)
$ENCRYPTION_KEY = @(73,22,190,88,245,12,67,233,112,45,78,156,99,201,37,88,144,67,223,111,89,45,178,234,56,123,88,167,234,78,45,199)

# Зашифрованный пароль администратора
$ENCRYPTED_ADMIN_PASSWORD = "76492d1116743f0423413b16050a5345MgB8AGoAaQBaADAAZwB3ADAAOAB2AFEAYgBNAHMAZAB0AHoAUwBCAEYAbAA0AGcAPQA9AHwANQAyADQANQAzAGEAZABiADgAOAA1ADkAOABhADIAYgBiAGQAOQAyAGQANABmADAANgBiADQAOQAwADkAOQBlADAAYQAwADAAZQA2ADAAMwA1ADcAOQBiADcAZABlADQAMAAwADEAOQA5ADIAYgBhAGUAYwBhAGYAMgA4AGQAMgA="

# =============================================================================
# ФУНКЦИЯ РАСШИФРОВКИ ПАРОЛЯ
# =============================================================================
function Get-DecryptedPassword {
    param([string]$EncryptedPassword, [byte[]]$Key)
    try {
        $securePassword = $EncryptedPassword | ConvertTo-SecureString -Key $Key
        $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
        return [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
    }
    catch {
        Write-Host "ERROR: Failed to decrypt password. Script may be corrupted!" -ForegroundColor Red
        exit 1
    }
}

# =============================================================================
# Функция: Проверка существования компьютера в новом домене
# =============================================================================

function Test-ComputerExistsInDomain {
    param(
        [string]$ComputerName,
        [string]$Domain,
        [string]$DomainController,
        [System.Management.Automation.PSCredential]$Credential
    )

    try {
        # Метод 1: Проверка через ADSI (работает без модуля ActiveDirectory)
        $searcher = New-Object DirectoryServices.DirectorySearcher
        $searcher.SearchRoot = New-Object DirectoryServices.DirectoryEntry("LDAP://$DomainController", $Credential.UserName, $Credential.GetNetworkCredential().Password)
        $searcher.Filter = "(&(objectClass=computer)(cn=$ComputerName))"
        $result = $searcher.FindOne()

        if ($result) {
            return $true
        } else {
            return $false
        }
    }
    catch {
        Write-Host "Warning: Cannot check computer existence in AD: $_" -ForegroundColor Yellow
        # Fallback: проверка через DNS
        try {
            $null = Resolve-DnsName -Name "$ComputerName.$Domain" -Server $DomainController -ErrorAction Stop
            return $true
        }
        catch {
            return $false
        }
    }
}

# =============================================================================
# Функция: Генерация уникального имени компьютера
# =============================================================================

function Get-UniqueComputerName {
    param(
        [string]$BaseComputerName,
        [string]$Domain,
        [string]$DomainController,
        [System.Management.Automation.PSCredential]$Credential
    )

    # Проверяем базовое имя
    $testName = $BaseComputerName
    Write-Host "Checking if '$testName' is available in domain '$Domain'..." -ForegroundColor Cyan

    if (-not (Test-ComputerExistsInDomain -ComputerName $testName -Domain $Domain -DomainController $DomainController -Credential $Credential)) {
        Write-Host "Computer name '$testName' is available!" -ForegroundColor Green
        return $testName
    }

    # Если занято - ищем свободное имя с суффиксом
    Write-Host "Computer name '$testName' already exists. Searching for available name..." -ForegroundColor Yellow

    for ($i = 1; $i -le 999; $i++) {
        $suffix = $i.ToString("D2")  # Форматируем как 01, 02, 03...

        # Ограничение NetBIOS: максимум 15 символов
        if ($BaseComputerName.Length + $suffix.Length -gt 15) {
            # Обрезаем базовое имя
            $truncatedBase = $BaseComputerName.Substring(0, 15 - $suffix.Length)
            $testName = "$truncatedBase$suffix"
        } else {
            $testName = "$BaseComputerName$suffix"
        }

        Write-Host "  Trying: $testName..." -ForegroundColor Gray

        if (-not (Test-ComputerExistsInDomain -ComputerName $testName -Domain $Domain -DomainController $DomainController -Credential $Credential)) {
            Write-Host "Found available name: '$testName'" -ForegroundColor Green
            return $testName
        }
    }

    # Если не нашли за 999 попыток - ошибка
    throw "Cannot find unique computer name! All variants from $BaseComputerName-01 to $BaseComputerName-999 are taken."
}

# =============================================================================
# НАЧАЛО ВЫПОЛНЕНИЯ СКРИПТА
# =============================================================================

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "Domain Migration: $OLD_DOMAIN -> $NEW_DOMAIN" -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

# Расшифровка пароля администратора
Write-Host "Decrypting credentials..." -ForegroundColor Cyan
$ADMIN_PASSWORD = Get-DecryptedPassword -EncryptedPassword $ENCRYPTED_ADMIN_PASSWORD -Key $ENCRYPTION_KEY
Write-Host "Credentials ready!" -ForegroundColor Green

# Подготовка учетных данных для нового домена
try {
    $securePassword = ConvertTo-SecureString $ADMIN_PASSWORD -AsPlainText -Force
    $newDomainCredential = New-Object System.Management.Automation.PSCredential($NEW_DOMAIN_USER, $securePassword)
}
catch {
    Write-Host "Error preparing credentials: $_" -ForegroundColor Red
    exit 1
}

# =============================================================================
# Шаг 0: Изменение DNS на новый домен (КРИТИЧНО!)
# =============================================================================

Write-Host "`n[Step 0] Changing DNS to new domain..." -ForegroundColor Green

$adapters = Get-NetAdapter | Where-Object {$_.Status -eq "Up"}
foreach ($adapter in $adapters) {
    $adapterName = $adapter.Name
    Write-Host "Changing DNS for adapter: $adapterName" -ForegroundColor Cyan

    try {
        # Устанавливаем primary DNS через netsh
        $result1 = netsh interface ip set dns name="$adapterName" static $NEW_DNS_PRIMARY 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-Host "  Primary DNS set to: $NEW_DNS_PRIMARY" -ForegroundColor Green
        } else {
            Write-Host "  WARNING: Failed to set primary DNS: $result1" -ForegroundColor Yellow
        }

        # Добавляем secondary DNS
        $result2 = netsh interface ip add dns name="$adapterName" addr=$NEW_DNS_SECONDARY index=2 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-Host "  Secondary DNS set to: $NEW_DNS_SECONDARY" -ForegroundColor Green
        } else {
            Write-Host "  WARNING: Failed to set secondary DNS: $result2" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "  ERROR changing DNS: $_" -ForegroundColor Red
    }
}

# Очистка DNS кэша
Write-Host "Clearing DNS cache..." -ForegroundColor Cyan
ipconfig /flushdns | Out-Null
Write-Host "DNS cache cleared!" -ForegroundColor Green

# Проверка DNS
Write-Host "`nVerifying DNS settings:" -ForegroundColor Cyan
foreach ($adapter in $adapters) {
    $dns = Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue
    if ($dns) {
        Write-Host "  $($adapter.Name): $($dns.ServerAddresses -join ', ')" -ForegroundColor Gray
    }
}

# Даем время на применение DNS
Start-Sleep -Seconds 2

Write-Host "DNS configuration completed!" -ForegroundColor Green

# =============================================================================
# Шаг 1: Получение текущего имени и генерация нового
# =============================================================================

Write-Host "`n[Step 1] Determining new computer name..." -ForegroundColor Green

$currentComputerName = $env:COMPUTERNAME
Write-Host "Current computer name: $currentComputerName" -ForegroundColor Cyan

try {
    $suggestedComputerName = Get-UniqueComputerName -BaseComputerName $currentComputerName -Domain $NEW_DOMAIN -DomainController $NEW_DOMAIN_DC -Credential $newDomainCredential
    Write-Host "Suggested computer name: $suggestedComputerName" -ForegroundColor Green
}
catch {
    Write-Host "Error determining unique computer name: $_" -ForegroundColor Red
    exit 1
}

# =============================================================================
# ЗАПРОС ИМЕНИ КОМПЬЮТЕРА ОТ АДМИНИСТРАТОРА
# =============================================================================

Write-Host "`n========================================" -ForegroundColor Yellow
Write-Host "ADMINISTRATOR: SET COMPUTER NAME" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Yellow
Write-Host "`nCurrent computer name: $currentComputerName" -ForegroundColor Cyan
Write-Host "Suggested new name: $suggestedComputerName" -ForegroundColor Cyan
Write-Host ""
Write-Host "NAMING FORMAT: ws-<object>-<dept>-<num>" -ForegroundColor Green
Write-Host "Examples:" -ForegroundColor Gray
Write-Host "  - ws-aurum-ls-009" -ForegroundColor Gray
Write-Host "  - ws-vtr-ai-009" -ForegroundColor Gray
Write-Host "  - ws-hgr-kk-10" -ForegroundColor Gray
Write-Host ""
Write-Host "IMPORTANT: Max 15 characters (NetBIOS limit)" -ForegroundColor Yellow
Write-Host ""
Write-Host "Please enter the desired computer name for the new domain." -ForegroundColor White
Write-Host "Press ENTER to use suggested name: $suggestedComputerName" -ForegroundColor Gray

$inputComputerName = Read-Host "`nEnter computer name (or press ENTER for suggested)"

if ([string]::IsNullOrWhiteSpace($inputComputerName)) {
    $newComputerName = $suggestedComputerName
    Write-Host "`nUsing suggested name: $newComputerName" -ForegroundColor Green
} else {
    # Проверка введенного имени (удаление недопустимых символов и ограничение длины)
    $newComputerName = $inputComputerName -replace '[^a-zA-Z0-9\-]', ''

    if ($newComputerName.Length -gt 15) {
        Write-Host "`nWARNING: Name too long (max 15 chars). Truncating..." -ForegroundColor Yellow
        $newComputerName = $newComputerName.Substring(0, 15)
    }

    if ($newComputerName.Length -eq 0) {
        Write-Host "`nERROR: Invalid computer name! Using suggested name instead." -ForegroundColor Red
        $newComputerName = $suggestedComputerName
    }

    Write-Host "`nComputer name set to: $newComputerName" -ForegroundColor Green

    # Проверка уникальности введенного имени
    Write-Host "Checking if '$newComputerName' is available in domain..." -ForegroundColor Cyan
    $isAvailable = -not (Test-ComputerExistsInDomain -ComputerName $newComputerName -Domain $NEW_DOMAIN -DomainController $NEW_DOMAIN_DC -Credential $newDomainCredential)

    if (-not $isAvailable) {
        Write-Host "WARNING: Computer name '$newComputerName' already exists in domain!" -ForegroundColor Red
        Write-Host "Migration will continue, but domain join may fail." -ForegroundColor Yellow
        Write-Host "Press Ctrl+C to cancel, or wait 5 seconds to continue..." -ForegroundColor Yellow
        Start-Sleep -Seconds 5
    } else {
        Write-Host "Computer name is available!" -ForegroundColor Green
    }
}

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "Migration Summary:" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Old domain: $OLD_DOMAIN" -ForegroundColor Gray
Write-Host "  New domain: $NEW_DOMAIN" -ForegroundColor Gray
Write-Host "  Old name: $currentComputerName" -ForegroundColor Gray
Write-Host "  New name: $newComputerName" -ForegroundColor Green
Write-Host "`nStarting migration in 5 seconds..." -ForegroundColor Yellow
Write-Host "Press Ctrl+C to cancel..." -ForegroundColor Red
Start-Sleep -Seconds 5

# =============================================================================
# Шаг 2: Выход из старого домена
# =============================================================================

$CS = Get-CimInstance Win32_ComputerSystem

Write-Host "`n[Step 2] Ejecting from domain '$OLD_DOMAIN'..." -ForegroundColor Green

# Проверяем, что мы действительно в домене
if ($CS.PartOfDomain -eq $false) {
    Write-Host "Computer is not part of a domain. Skipping domain ejection." -ForegroundColor Yellow
} else {
    Write-Host "Current domain: $($CS.Domain)" -ForegroundColor Cyan

    # Для выхода используем учетку текущего пользователя (он уже аутентифицирован в домене)
    # Получаем креды текущего пользователя
    $currentUser = "$env:USERDOMAIN\$env:USERNAME"

    Write-Host "Attempting to unjoin using current user credentials: $currentUser" -ForegroundColor Gray

    # Пробуем два метода
    $ejectResult = $null

    # Метод 1: Force без кредов
    try {
        $ejectResult = $CS | Invoke-CimMethod -MethodName UnjoinDomainOrWorkGroup -Arguments @{
            FUnjoinOptions = 4
        }
    } catch {
        Write-Host "Force method failed, trying with credentials..." -ForegroundColor Yellow
    }

    # Метод 2: С кредами (если метод 1 не сработал)
    if ($ejectResult -and $ejectResult.ReturnValue -ne 0) {
        Write-Host "Trying unjoin with domain admin credentials..." -ForegroundColor Yellow

        # Создаем креды для выхода из старого домена (используем расшифрованный пароль)
        $oldDomainUser = "$OLD_DOMAIN\$OLD_DOMAIN_ADMIN_USER"
        $oldDomainSecPass = ConvertTo-SecureString $ADMIN_PASSWORD -AsPlainText -Force
        $oldDomainCred = New-Object System.Management.Automation.PSCredential($oldDomainUser, $oldDomainSecPass)

        Write-Host "Using credentials: $oldDomainUser" -ForegroundColor Gray

        # Используем Remove-Computer (более высокоуровневая команда)
        try {
            Remove-Computer -UnjoinDomainCredential $oldDomainCred -WorkgroupName "WORKGROUP" -Force -ErrorAction Stop
            $ejectResult = [PSCustomObject]@{ ReturnValue = 0 }
            Write-Host "Successfully ejected using credentials!" -ForegroundColor Green
        } catch {
            Write-Host "Error: $_" -ForegroundColor Red
            $ejectResult = [PSCustomObject]@{ ReturnValue = 5 }
        }
    }

    if ($ejectResult.ReturnValue -eq 0) {
        Write-Host "Successfully ejected from domain!" -ForegroundColor Green
    } else {
        Write-Host "Error ejecting from domain: $($ejectResult.ReturnValue)" -ForegroundColor Red
        Write-Host "`nThis usually means:" -ForegroundColor Yellow
        Write-Host "  - Need elevated (UAC) administrator rights" -ForegroundColor Gray
        Write-Host "  - Or need domain admin credentials" -ForegroundColor Gray
        Write-Host "`nFor 700 computers, use GPO Startup Script (runs as SYSTEM)!" -ForegroundColor Cyan
        exit 1
    }
}

# =============================================================================
# Шаг 3: Переименование компьютера
# =============================================================================

Write-Host "`n[Step 3] Renaming computer to '$newComputerName'..." -ForegroundColor Green

if ($currentComputerName -ne $newComputerName) {
    $renameResult = $CS | Invoke-CimMethod -MethodName Rename -Arguments @{
        Name = $newComputerName
    }

    if ($renameResult.ReturnValue -eq 0) {
        Write-Host "Computer renamed successfully!" -ForegroundColor Green
    } else {
        Write-Host "Computer rename error: $($renameResult.ReturnValue)" -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "Computer name unchanged (already '$newComputerName')" -ForegroundColor Yellow
}

# =============================================================================
# Шаг 4: Очистка данных старого домена
# =============================================================================

Write-Host "`n[Step 4] Cleaning old domain data..." -ForegroundColor Green

# Удаление Group Policy
Write-Host "  Removing Group Policy files..." -ForegroundColor Gray
cmd /c 'RMDIR /S /Q "%WinDir%\System32\GroupPolicyUsers"' 2>$null
cmd /c 'RMDIR /S /Q "%WinDir%\System32\GroupPolicy"' 2>$null

# Сброс security policies
Write-Host "  Resetting security policies..." -ForegroundColor Gray
cmd /c 'secedit /configure /cfg %windir%\inf\defltbase.inf /db defltbase.sdb /verbose' 2>$null | Out-Null

# Очистка истории Group Policy
Write-Host "  Cleaning Group Policy history..." -ForegroundColor Gray
cmd /c 'DEL /S /F /Q "%ALLUSERSPROFILE%\Microsoft\Group Policy\History\*.*"' 2>$null

# Очистка реестра
Write-Host "  Cleaning registry..." -ForegroundColor Gray
cmd /c 'REG DELETE "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy" /f' 2>$null | Out-Null
cmd /c 'REG DELETE "HKLM\Software\Policies\Microsoft" /f' 2>$null | Out-Null
cmd /c 'REG DELETE "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies" /f' 2>$null | Out-Null
cmd /c 'REG DELETE "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies" /f' 2>$null | Out-Null
cmd /c 'REG DELETE "HKCU\Software\Policies\Microsoft" /f' 2>$null | Out-Null
cmd /c 'REG DELETE "HKCU\Software\Microsoft\Windows\CurrentVersion\Group Policy Objects" /f' 2>$null | Out-Null

# Очистка Kerberos tickets
Write-Host "  Purging Kerberos tickets..." -ForegroundColor Gray
cmd /c 'klist purge' 2>$null | Out-Null

# Удаление security database
Write-Host "  Removing security database..." -ForegroundColor Gray
cmd /c 'DEL /F /Q "C:\WINDOWS\security\Database\secedit.sdb"' 2>$null

# Обновление Group Policy
Write-Host "  Updating Group Policy..." -ForegroundColor Gray
cmd /c 'gpupdate /force' 2>$null | Out-Null

Write-Host "Domain data cleanup completed!" -ForegroundColor Green

# =============================================================================
# Шаг 5: Управление локальными пользователями
# =============================================================================

Write-Host "`n[Step 5] Managing local users..." -ForegroundColor Green

# ВАЖНО: Не удаляем встроенные учетки (Administrator, Guest)
$localUsers = Get-LocalUser | Where-Object {
    $_.Enabled -eq $true -and
    $_.SID -notlike "S-1-5-21-*-500" -and  # Не Administrator
    $_.SID -notlike "S-1-5-21-*-501"       # Не Guest
}

if ($localUsers.Count -gt 0) {
    Write-Host "Found $($localUsers.Count) local users to remove:" -ForegroundColor Cyan
    $localUsers | ForEach-Object { Write-Host "  - $($_.Name)" -ForegroundColor Gray }

    $localUsers | ForEach-Object {
        $userName = $_.Name
        try {
            Remove-LocalUser -Name $userName -ErrorAction Stop
            Write-Host "  Removed: $userName" -ForegroundColor Green
        } catch {
            Write-Host "  Error removing '$userName': $_" -ForegroundColor Red
        }
    }
} else {
    Write-Host "No local users to remove." -ForegroundColor Yellow
}

# =============================================================================
# Шаг 6: Настройка профиля по умолчанию
# =============================================================================

Write-Host "`n[Step 6] Configuring default user profile..." -ForegroundColor Green

reg load "HKU\TempDefault" "C:\Users\Default\NTUSER.DAT" 2>$null

reg add "HKU\TempDefault\Software\Microsoft\Windows\CurrentVersion\Privacy" /v TailoredExperiencesWithDiagnosticDataEnabled /t REG_DWORD /d 0 /f | Out-Null
reg add "HKU\TempDefault\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoPrivacySettings /t REG_DWORD /d 1 /f | Out-Null

reg unload "HKU\TempDefault" 2>$null

# Отключение Windows consumer features
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v DisableWindowsConsumerFeatures /t REG_DWORD /d 1 /f | Out-Null
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v DisableSoftLanding /t REG_DWORD /d 1 /f | Out-Null
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v DisableThirdPartySuggestions /t REG_DWORD /d 1 /f | Out-Null
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OOBE" /v DisablePrivacyExperience /t REG_DWORD /d 1 /f | Out-Null
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v DoNotShowFeedbackNotifications /t REG_DWORD /d 1 /f | Out-Null
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v AllowTelemetry /t REG_DWORD /d 0 /f | Out-Null

Write-Host "Default user profile configured!" -ForegroundColor Green

# =============================================================================
# Шаг 7: Создание локального админа
# =============================================================================

Write-Host "`n[Step 7] Creating local Admin account..." -ForegroundColor Green

try {
    # Проверяем, существует ли уже
    if (Get-LocalUser -Name "Admin" -ErrorAction SilentlyContinue) {
        Write-Host "Local Admin account already exists." -ForegroundColor Yellow
    } else {
        New-LocalUser -Name "Admin" -NoPassword -Description "Local Administrator (migration)" | Out-Null
        Set-LocalUser -Name "Admin" -PasswordNeverExpires $true
        Add-LocalGroupMember -SID "S-1-5-32-544" -Member "Admin"
        Enable-LocalUser -Name "Admin"
        Write-Host "Local Admin account created!" -ForegroundColor Green
    }
} catch {
    Write-Host "Error creating Admin account: $_" -ForegroundColor Red
    exit 1
}

# =============================================================================
# Шаг 8: Настройка автоматического ввода в домен после перезагрузки
# =============================================================================

Write-Host "`n[Step 8] Configuring post-reboot domain join..." -ForegroundColor Green

$runAfterReboot = {
    param($Domain, $Username, $ComputerName, $DomainDC, $DnsPrimary)

    $regPath = "HKLM:\SOFTWARE\DomainMigrationCompleted"

    if (-NOT (Test-Path $regPath)) {
        # Первый запуск после перезагрузки - вводим в домен
        try {
            New-Item -Path $regPath -Force | Out-Null

            # =============================================================================
            # УМНАЯ ПРОВЕРКА ГОТОВНОСТИ СИСТЕМЫ
            # =============================================================================

            $maxAttempts = 20  # Максимум попыток (20 * 10 сек = 200 сек = 3.3 минуты)
            $attempt = 0
            $systemReady = $false

            "Starting system readiness check..." | Out-File "C:\domain_migration_log.txt" -Append

            while ($attempt -lt $maxAttempts -and -not $systemReady) {
                $attempt++
                $checksPassed = 0
                $totalChecks = 4  # Только базовые проверки (сеть, DNS, ping, Explorer)

                "[Attempt $attempt/$maxAttempts] Checking system readiness..." | Out-File "C:\domain_migration_log.txt" -Append

                # CHECK 1: Сетевой адаптер активен
                try {
                    $activeAdapter = Get-NetAdapter | Where-Object {$_.Status -eq "Up"} | Select-Object -First 1
                    if ($activeAdapter) {
                        "  [OK] Network adapter is UP: $($activeAdapter.Name)" | Out-File "C:\domain_migration_log.txt" -Append
                        $checksPassed++
                    } else {
                        "  [WAIT] Network adapter not ready yet" | Out-File "C:\domain_migration_log.txt" -Append
                    }
                } catch {
                    "  [ERROR] Cannot check network adapter: $_" | Out-File "C:\domain_migration_log.txt" -Append
                }

                # CHECK 2: DNS резолвится
                try {
                    $dnsResult = Resolve-DnsName $Domain -ErrorAction Stop
                    if ($dnsResult) {
                        "  [OK] DNS resolves: $Domain -> $($dnsResult[0].IPAddress)" | Out-File "C:\domain_migration_log.txt" -Append
                        $checksPassed++
                    }
                } catch {
                    "  [WAIT] DNS not resolving yet: $_" | Out-File "C:\domain_migration_log.txt" -Append
                }

                # CHECK 3: Ping контроллера домена
                try {
                    $pingResult = Test-Connection $DomainDC -Count 1 -ErrorAction Stop
                    if ($pingResult) {
                        "  [OK] Ping to DC successful: $DomainDC" | Out-File "C:\domain_migration_log.txt" -Append
                        $checksPassed++
                    }
                } catch {
                    "  [WAIT] Cannot ping DC yet: $_" | Out-File "C:\domain_migration_log.txt" -Append
                }

                # CHECK 4: Проводник (Explorer) загрузился - индикатор полной готовности GUI
                try {
                    $explorerProcess = Get-Process -Name explorer -ErrorAction SilentlyContinue
                    if ($explorerProcess) {
                        "  [OK] Explorer process is running (user profile fully loaded)" | Out-File "C:\domain_migration_log.txt" -Append
                        $checksPassed++
                    } else {
                        "  [WAIT] Explorer not running yet (user profile still loading...)" | Out-File "C:\domain_migration_log.txt" -Append
                    }
                } catch {
                    "  [WAIT] Cannot check Explorer process: $_" | Out-File "C:\domain_migration_log.txt" -Append
                }

                # CHECK 5: LDAP порт 389 доступен (информационная проверка, Add-Computer сам разберется)
                try {
                    $tcpClient = New-Object System.Net.Sockets.TcpClient
                    $connection = $tcpClient.BeginConnect($DomainDC, 389, $null, $null)
                    $wait = $connection.AsyncWaitHandle.WaitOne(3000, $false)
                    if ($wait) {
                        $tcpClient.EndConnect($connection)
                        "  [INFO] LDAP port 389 accessible" | Out-File "C:\domain_migration_log.txt" -Append
                    } else {
                        "  [INFO] LDAP port 389 timeout (Add-Computer will handle it)" | Out-File "C:\domain_migration_log.txt" -Append
                    }
                    $tcpClient.Close()
                } catch {
                    "  [INFO] LDAP port check failed (Add-Computer will handle it)" | Out-File "C:\domain_migration_log.txt" -Append
                }

                # CHECK 6: Kerberos порт 88 доступен (информационная проверка, Add-Computer сам разберется)
                try {
                    $tcpClient = New-Object System.Net.Sockets.TcpClient
                    $connection = $tcpClient.BeginConnect($DomainDC, 88, $null, $null)
                    $wait = $connection.AsyncWaitHandle.WaitOne(3000, $false)
                    if ($wait) {
                        $tcpClient.EndConnect($connection)
                        "  [INFO] Kerberos port 88 accessible" | Out-File "C:\domain_migration_log.txt" -Append
                    } else {
                        "  [INFO] Kerberos port 88 timeout (Add-Computer will handle it)" | Out-File "C:\domain_migration_log.txt" -Append
                    }
                    $tcpClient.Close()
                } catch {
                    "  [INFO] Kerberos port check failed (Add-Computer will handle it)" | Out-File "C:\domain_migration_log.txt" -Append
                }

                # Проверяем результаты (нужны 4 базовые проверки, LDAP/Kerberos - информационные)
                "[Result] $checksPassed/$totalChecks required checks passed" | Out-File "C:\domain_migration_log.txt" -Append

                if ($checksPassed -eq $totalChecks) {
                    $systemReady = $true
                    "[SUCCESS] System is READY! All required checks passed after $attempt attempts" | Out-File "C:\domain_migration_log.txt" -Append
                } else {
                    if ($attempt -lt $maxAttempts) {
                        "  Waiting 10 seconds before next check..." | Out-File "C:\domain_migration_log.txt" -Append
                        Start-Sleep -Seconds 10
                    }
                }
            }

            if (-not $systemReady) {
                $errorMsg = "TIMEOUT: System not ready after $maxAttempts attempts ($(($maxAttempts * 10)) seconds)"
                $errorMsg | Out-File "C:\domain_migration_log.txt" -Append
                $errorMsg | Out-File "C:\domain_migration_error.log" -Append
                throw $errorMsg
            }

            # =============================================================================
            # СИСТЕМА ГОТОВА - ЗАПУСКАЕМ FINISH_MIGRATION.ps1
            # =============================================================================

            "[SUCCESS] System is READY - launching FINISH_MIGRATION.ps1" | Out-File "C:\domain_migration_log.txt" -Append

            # Запускаем FINISH_MIGRATION.ps1 с явным обходом Execution Policy
            # Используем Start-Process с -Wait чтобы дождаться завершения
            $processArgs = "-NoProfile -ExecutionPolicy Bypass -File `"C:\FINISH_MIGRATION.ps1`""
            "Executing: PowerShell.exe $processArgs" | Out-File "C:\domain_migration_log.txt" -Append

            Start-Process -FilePath "PowerShell.exe" -ArgumentList $processArgs -Wait -NoNewWindow
        }
        catch {
            # Логируем ошибку (например timeout или ошибка проверок)
            "FATAL ERROR during readiness checks: $_" | Out-File "C:\domain_migration_log.txt" -Append
            $_ | Out-File "C:\domain_migration_error.log" -Append

            # Удаляем flag чтобы можно было повторить
            Remove-Item -Path $regPath -Force -ErrorAction SilentlyContinue
        }
    } else {
        # Второй запуск - очистка
        "Second run detected - cleaning up..." | Out-File "C:\domain_migration_log.txt" -Append
        Remove-Item -Path $regPath -Force -ErrorAction SilentlyContinue
        Unregister-ScheduledTask -TaskName 'JoinNewDomainAfterReboot' -Confirm:$false -ErrorAction SilentlyContinue
    }
}

# Передаем параметры в scriptblock и вызываем функцию
$scriptWithParams = [ScriptBlock]::Create(@"
`$Domain = '$NEW_DOMAIN'
`$Username = '$NEW_DOMAIN_USER'
`$ComputerName = '$newComputerName'
`$DomainDC = '$NEW_DOMAIN_DC'
`$DnsPrimary = '$NEW_DNS_PRIMARY'

# Определяем функцию
$($runAfterReboot.ToString())

# Вызываем функцию с параметрами
& `$runAfterReboot -Domain `$Domain -Username `$Username -ComputerName `$ComputerName -DomainDC `$DomainDC -DnsPrimary `$DnsPrimary
"@)

# Кодируем в Base64
$encodedCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($scriptWithParams.ToString()))

# Проверяем что FINISH_MIGRATION.ps1 скопирован в C:\ (должен быть скопирован через RUN_AS_ADMIN.bat)
if (-not (Test-Path "C:\FINISH_MIGRATION.ps1")) {
    Write-Host "WARNING: C:\FINISH_MIGRATION.ps1 not found!" -ForegroundColor Yellow
    Write-Host "Scheduled task may fail. Make sure to run via RUN_AS_ADMIN.bat" -ForegroundColor Yellow
}

# Создаем задание в Планировщике с обходом Execution Policy
$action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -EncodedCommand $encodedCommand"

# Trigger с задержкой 30 секунд после загрузки системы
$trigger = New-ScheduledTaskTrigger -AtStartup
$trigger.Delay = 'PT30S'  # ISO 8601 формат: 30 секунд

# Настройки задачи
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 30)

$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

# Удаляем старое задание если есть
Unregister-ScheduledTask -TaskName 'JoinNewDomainAfterReboot' -Confirm:$false -ErrorAction SilentlyContinue

# Регистрируем новое
Register-ScheduledTask -TaskName 'JoinNewDomainAfterReboot' -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Description "Automatic domain join after migration" | Out-Null

Write-Host "Scheduled task configured!" -ForegroundColor Green

# =============================================================================
# Завершение
# =============================================================================

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "Migration preparation completed!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "`nSummary:" -ForegroundColor Yellow
Write-Host "  Old domain: $OLD_DOMAIN" -ForegroundColor Gray
Write-Host "  New domain: $NEW_DOMAIN" -ForegroundColor Gray
Write-Host "  Old computer name: $currentComputerName" -ForegroundColor Gray
Write-Host "  New computer name: $newComputerName" -ForegroundColor Gray
Write-Host "`nThe computer will now restart and automatically join the new domain." -ForegroundColor Yellow
Write-Host "After restart, login as: $NEW_DOMAIN\<your_username>" -ForegroundColor Yellow

Start-Sleep -Seconds 5

Write-Host "`nRestarting in 10 seconds..." -ForegroundColor Red
Write-Host "Press Ctrl+C to cancel." -ForegroundColor Red
Start-Sleep -Seconds 10

Restart-Computer -Force
