# =============================================================================
# Ручное завершение миграции - ввод в новый домен
# =============================================================================

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "Finish Migration - Join New Domain" -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

# =============================================================================
# ЗАШИФРОВАННЫЙ ПАРОЛЬ (для безопасности)
# =============================================================================
# Ключ шифрования (НЕ ИЗМЕНЯТЬ! Используется обоими скриптами)
$ENCRYPTION_KEY = @(73,22,190,88,245,12,67,233,112,45,78,156,99,201,37,88,144,67,223,111,89,45,178,234,56,123,88,167,234,78,45,199)

# Зашифрованный пароль администратора
$ENCRYPTED_ADMIN_PASSWORD = "76492d1116743f0423413b16050a5345MgB8AGoAaQBaADAAZwB3ADAAOAB2AFEAYgBNAHMAZAB0AHoAUwBCAEYAbAA0AGcAPQA9AHwANQAyADQANQAzAGEAZABiADgAOAA1ADkAOABhADIAYgBiAGQAOQAyAGQANABmADAANgBiADQAOQAwADkAOQBlADAAYQAwADAAZQA2ADAAMwA1ADcAOQBiADcAZABlADQAMAAwADEAOQA5ADIAYgBhAGUAYwBhAGYAMgA4AGQAMgA="

# =============================================================================
# ФУНКЦИЯ РАСШИФРОВКИ ПАРОЛЯ
# =============================================================================
function Get-DecryptedPassword {
    param([string]$EncryptedPassword, [byte[]]$Key)
    try {
        $securePassword = $EncryptedPassword | ConvertTo-SecureString -Key $Key
        $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
        return [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
    }
    catch {
        Write-Host "ERROR: Failed to decrypt password. Script may be corrupted!" -ForegroundColor Red
        "ERROR: Failed to decrypt password. Script may be corrupted!" | Out-File "C:\domain_migration_error.log" -Append
        exit 1
    }
}

# Конфигурация
$NEW_DOMAIN = "ukpomosch.local"
$NEW_DOMAIN_USER = "ukpomosch.local\chaikin_aa"

# Расшифровка пароля
Write-Host "Decrypting credentials..." -ForegroundColor Cyan
$NEW_DOMAIN_PASS = Get-DecryptedPassword -EncryptedPassword $ENCRYPTED_ADMIN_PASSWORD -Key $ENCRYPTION_KEY
Write-Host "Credentials ready!" -ForegroundColor Green

# Проверка текущего статуса
$cs = Get-CimInstance Win32_ComputerSystem
Write-Host "Current computer name: $($cs.Name)" -ForegroundColor Yellow
Write-Host "In domain: $($cs.PartOfDomain)" -ForegroundColor Yellow
Write-Host "Domain: $($cs.Domain)" -ForegroundColor Yellow

if ($cs.PartOfDomain -and $cs.Domain -eq $NEW_DOMAIN) {
    Write-Host "`nComputer is already in $NEW_DOMAIN!" -ForegroundColor Green
    Write-Host "Migration completed successfully!" -ForegroundColor Green
    pause
    exit 0
}

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "Joining domain: $NEW_DOMAIN" -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

# Создаем креды для нового домена
$secpass = ConvertTo-SecureString $NEW_DOMAIN_PASS -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential($NEW_DOMAIN_USER, $secpass)

Write-Host "Using credentials: $NEW_DOMAIN_USER" -ForegroundColor Gray
Write-Host "`nAttempting to join domain..." -ForegroundColor Cyan

try {
    # Логируем начало
    "Launching domain join via FINISH_MIGRATION.ps1..." | Out-File "C:\domain_migration_log.txt" -Append

    # Вход в домен
    Add-Computer -DomainName $NEW_DOMAIN -Credential $cred -Force -ErrorAction Stop

    Write-Host "`n========================================" -ForegroundColor Green
    Write-Host "SUCCESS!" -ForegroundColor Green
    Write-Host "========================================`n" -ForegroundColor Green

    Write-Host "Computer successfully joined: $NEW_DOMAIN" -ForegroundColor Green
    Write-Host "`nComputer will restart in 5 seconds..." -ForegroundColor Yellow

    # Логируем успех
    "Domain join successful! $NEW_DOMAIN" | Out-File "C:\domain_migration_log.txt" -Append
    "Computer will restart in 5 seconds..." | Out-File "C:\domain_migration_log.txt" -Append

    # Очистка
    Unregister-ScheduledTask -TaskName 'JoinNewDomainAfterReboot' -Confirm:$false -ErrorAction SilentlyContinue
    Remove-Item -Path "HKLM:\SOFTWARE\DomainMigrationCompleted" -Force -ErrorAction SilentlyContinue

    Start-Sleep -Seconds 5
    Restart-Computer -Force

}
catch {
    Write-Host "`n========================================" -ForegroundColor Red
    Write-Host "ERROR!" -ForegroundColor Red
    Write-Host "========================================`n" -ForegroundColor Red

    Write-Host "Failed to join domain: $_`n" -ForegroundColor Yellow

    # Логируем ошибку
    "FATAL ERROR during domain join: $_" | Out-File "C:\domain_migration_log.txt" -Append

    # Детальный error log
    "========================================" | Out-File "C:\domain_migration_error.log" -Append
    "Domain join FAILED - $(Get-Date)" | Out-File "C:\domain_migration_error.log" -Append
    "========================================" | Out-File "C:\domain_migration_error.log" -Append
    "Domain: $NEW_DOMAIN" | Out-File "C:\domain_migration_error.log" -Append
    "Username: $NEW_DOMAIN_USER" | Out-File "C:\domain_migration_error.log" -Append
    "" | Out-File "C:\domain_migration_error.log" -Append
    "Error details:" | Out-File "C:\domain_migration_error.log" -Append
    $_ | Out-File "C:\domain_migration_error.log" -Append
    "" | Out-File "C:\domain_migration_error.log" -Append
    "Possible reasons:" | Out-File "C:\domain_migration_error.log" -Append
    "  1. Wrong credentials for $NEW_DOMAIN_USER" | Out-File "C:\domain_migration_error.log" -Append
    "  2. Cannot reach domain controller" | Out-File "C:\domain_migration_error.log" -Append
    "  3. DNS not configured for new domain" | Out-File "C:\domain_migration_error.log" -Append
    "  4. Network connectivity issues" | Out-File "C:\domain_migration_error.log" -Append
    "  5. LDAP/Kerberos ports blocked on DC" | Out-File "C:\domain_migration_error.log" -Append

    Write-Host "Possible reasons:" -ForegroundColor Yellow
    Write-Host "  1. Wrong credentials for $NEW_DOMAIN_USER" -ForegroundColor Gray
    Write-Host "  2. Cannot reach domain controller" -ForegroundColor Gray
    Write-Host "  3. DNS not configured for new domain" -ForegroundColor Gray
    Write-Host "  4. Network connectivity issues" -ForegroundColor Gray
    Write-Host "  5. LDAP/Kerberos ports blocked on DC`n" -ForegroundColor Gray

    Write-Host "Check:" -ForegroundColor Cyan
    Write-Host "  - ping $NEW_DOMAIN" -ForegroundColor Gray
    Write-Host "  - nslookup $NEW_DOMAIN" -ForegroundColor Gray
    Write-Host "  - C:\domain_migration_error.log for details`n" -ForegroundColor Gray

    # Если запущен интерактивно - показываем pause, если автоматически - просто exit
    if ([Environment]::UserInteractive) {
        pause
    }
    exit 1
}
