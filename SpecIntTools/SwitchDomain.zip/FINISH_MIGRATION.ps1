# =============================================================================
# Finish Migration - Join New Domain
# =============================================================================

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "Finish Migration - Join New Domain" -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

# =============================================================================
# ENCRYPTED PASSWORD (for security)
# =============================================================================
# Encryption key (DO NOT CHANGE! Used by both scripts)
$ENCRYPTION_KEY = @(73,22,190,88,245,12,67,233,112,45,78,156,99,201,37,88,144,67,223,111,89,45,178,234,56,123,88,167,234,78,45,199)

# Encrypted administrator password
$ENCRYPTED_ADMIN_PASSWORD = "76492d1116743f0423413b16050a5345MgB8AGoAaQBaADAAZwB3ADAAOAB2AFEAYgBNAHMAZAB0AHoAUwBCAEYAbAA0AGcAPQA9AHwANQAyADQANQAzAGEAZABiADgAOAA1ADkAOABhADIAYgBiAGQAOQAyAGQANABmADAANgBiADQAOQAwADkAOQBlADAAYQAwADAAZQA2ADAAMwA1ADcAOQBiADcAZABlADQAMAAwADEAOQA5ADIAYgBhAGUAYwBhAGYAMgA4AGQAMgA="

# =============================================================================
# PASSWORD DECRYPTION FUNCTION
# =============================================================================
function Get-DecryptedPassword {
    param([string]$EncryptedPassword, [byte[]]$Key)
    try {
        $securePassword = $EncryptedPassword | ConvertTo-SecureString -Key $Key
        $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
        return [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
    }
    catch {
        Write-Host "ERROR: Failed to decrypt password. Script may be corrupted!" -ForegroundColor Red
        "ERROR: Failed to decrypt password. Script may be corrupted!" | Out-File "C:\domain_migration_error.log" -Append
        exit 1
    }
}

# Configuration
$NEW_DOMAIN = "ukpomosch.local"
$NEW_DOMAIN_USER = "ukpomosch.local\chaikin_aa"

# Decrypt password
Write-Host "Decrypting credentials..." -ForegroundColor Cyan
$NEW_DOMAIN_PASS = Get-DecryptedPassword -EncryptedPassword $ENCRYPTED_ADMIN_PASSWORD -Key $ENCRYPTION_KEY
Write-Host "Credentials ready!" -ForegroundColor Green

# Check current status
$cs = Get-CimInstance Win32_ComputerSystem
Write-Host "Current computer name: $($cs.Name)" -ForegroundColor Yellow
Write-Host "In domain: $($cs.PartOfDomain)" -ForegroundColor Yellow
Write-Host "Domain: $($cs.Domain)" -ForegroundColor Yellow

if ($cs.PartOfDomain -and $cs.Domain -eq $NEW_DOMAIN) {
    Write-Host "`nComputer is already in $NEW_DOMAIN!" -ForegroundColor Green
    Write-Host "Migration completed successfully!" -ForegroundColor Green
    pause
    exit 0
}

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "Joining domain: $NEW_DOMAIN" -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

# Create credentials for new domain
$secpass = ConvertTo-SecureString $NEW_DOMAIN_PASS -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential($NEW_DOMAIN_USER, $secpass)

Write-Host "Using credentials: $NEW_DOMAIN_USER" -ForegroundColor Gray
Write-Host "`nAttempting to join domain..." -ForegroundColor Cyan

try {
    # Log start
    "Launching domain join via FINISH_MIGRATION.ps1..." | Out-File "C:\domain_migration_log.txt" -Append

    # Join domain
    Add-Computer -DomainName $NEW_DOMAIN -Credential $cred -Force -ErrorAction Stop

    Write-Host "`n========================================" -ForegroundColor Green
    Write-Host "SUCCESS!" -ForegroundColor Green
    Write-Host "========================================`n" -ForegroundColor Green

    Write-Host "Computer successfully joined: $NEW_DOMAIN" -ForegroundColor Green

    # =============================================================================
    # POST-JOIN: Restore default settings for new domain GPO (failsafe)
    # =============================================================================

    Write-Host "`n[POST-JOIN] Restoring default settings for new domain GPO..." -ForegroundColor Cyan

    $restoreSuccess = $true
    $restoreErrors = @()

    # -------------------------------------------------------------------------
    # STEP 1: Remove DisableCAD from primary registry location
    # -------------------------------------------------------------------------
    Write-Host "  [1/3] Removing primary registry override..." -ForegroundColor Gray

    $regPath1 = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
    $regName = "DisableCAD"

    try {
        # Check if path exists
        if (Test-Path $regPath1) {
            # Check if value exists
            $valueExists = $null
            try {
                $valueExists = Get-ItemProperty -Path $regPath1 -Name $regName -ErrorAction Stop
            } catch {
                # Value doesn't exist - nothing to remove
                $valueExists = $null
            }

            if ($valueExists) {
                Remove-ItemProperty -Path $regPath1 -Name $regName -ErrorAction Stop
                Write-Host "    [OK] Primary registry override removed" -ForegroundColor Green
                "Primary DisableCAD removed from registry" | Out-File "C:\domain_migration_log.txt" -Append
            } else {
                Write-Host "    [OK] No override present (already clean)" -ForegroundColor Green
            }
        } else {
            Write-Host "    [OK] Registry path does not exist (already clean)" -ForegroundColor Green
        }
    } catch {
        $errMsg = "Failed to remove primary registry value: $_"
        Write-Host "    [WARN] $errMsg" -ForegroundColor Yellow
        $restoreErrors += $errMsg
        $errMsg | Out-File "C:\domain_migration_log.txt" -Append
    }

    # -------------------------------------------------------------------------
    # STEP 2: Remove DisableCAD from alternate registry location (Winlogon)
    # -------------------------------------------------------------------------
    Write-Host "  [2/3] Removing alternate registry override (Winlogon)..." -ForegroundColor Gray

    $regPath2 = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"

    try {
        # Check if path exists
        if (Test-Path $regPath2) {
            # Check if value exists
            $valueExists2 = $null
            try {
                $valueExists2 = Get-ItemProperty -Path $regPath2 -Name $regName -ErrorAction Stop
            } catch {
                $valueExists2 = $null
            }

            if ($valueExists2) {
                Remove-ItemProperty -Path $regPath2 -Name $regName -ErrorAction Stop
                Write-Host "    [OK] Alternate registry override removed" -ForegroundColor Green
                "Alternate DisableCAD removed from Winlogon" | Out-File "C:\domain_migration_log.txt" -Append
            } else {
                Write-Host "    [OK] No override present (already clean)" -ForegroundColor Green
            }
        } else {
            Write-Host "    [OK] Registry path does not exist (already clean)" -ForegroundColor Green
        }
    } catch {
        $errMsg = "Failed to remove alternate registry value: $_"
        Write-Host "    [WARN] $errMsg" -ForegroundColor Yellow
        $restoreErrors += $errMsg
        $errMsg | Out-File "C:\domain_migration_log.txt" -Append
    }

    # -------------------------------------------------------------------------
    # STEP 3: Remove DisableCAD from security policy
    # -------------------------------------------------------------------------
    Write-Host "  [3/3] Cleaning security policy..." -ForegroundColor Gray

    try {
        $secEditExport = "$env:TEMP\secedit_restore_export_$(Get-Random).inf"
        $secEditImport = "$env:TEMP\secedit_restore_import_$(Get-Random).inf"
        $secEditDb = "$env:TEMP\secedit_restore_$(Get-Random).sdb"

        # Export current policy
        $exportResult = secedit /export /cfg $secEditExport /quiet 2>&1
        if (-not (Test-Path $secEditExport)) {
            throw "Failed to export security policy for cleanup"
        }

        # Read policy file
        $content = Get-Content $secEditExport -Encoding Unicode -ErrorAction Stop
        if ($content.Count -eq 0) {
            throw "Exported security policy file is empty"
        }

        Write-Host "    Security policy exported ($($content.Count) lines)" -ForegroundColor Gray

        # Check if DisableCAD exists in policy
        $cadFound = $false
        $newContent = @()

        foreach ($line in $content) {
            # Skip DisableCAD line
            if ($line -match 'MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\DisableCAD') {
                $cadFound = $true
                Write-Host "    Found DisableCAD in security policy - removing" -ForegroundColor Yellow
                "DisableCAD found in security policy and removed" | Out-File "C:\domain_migration_log.txt" -Append
            } else {
                $newContent += $line
            }
        }

        if ($cadFound) {
            # Save cleaned policy
            $newContent | Set-Content $secEditImport -Encoding Unicode -ErrorAction Stop

            # Import cleaned policy back
            $importResult = secedit /configure /db $secEditDb /cfg $secEditImport /quiet 2>&1

            Write-Host "    [OK] DisableCAD removed from security policy" -ForegroundColor Green
        } else {
            Write-Host "    [OK] DisableCAD not found in security policy (already clean)" -ForegroundColor Green
        }

        # Cleanup temporary files
        Remove-Item $secEditExport -Force -ErrorAction SilentlyContinue
        Remove-Item $secEditImport -Force -ErrorAction SilentlyContinue
        Remove-Item $secEditDb -Force -ErrorAction SilentlyContinue

    } catch {
        $errMsg = "Security policy cleanup error: $_"
        Write-Host "    [WARN] $errMsg" -ForegroundColor Yellow
        $restoreErrors += $errMsg
        $errMsg | Out-File "C:\domain_migration_log.txt" -Append

        # Cleanup on error
        Remove-Item "$env:TEMP\secedit_restore_*.inf" -Force -ErrorAction SilentlyContinue
        Remove-Item "$env:TEMP\secedit_restore_*.sdb" -Force -ErrorAction SilentlyContinue
    }

    # -------------------------------------------------------------------------
    # VERIFICATION
    # -------------------------------------------------------------------------
    Write-Host "`n  Verification:" -ForegroundColor Cyan

    # Verify primary registry cleaned
    try {
        $verifyReg = Get-ItemProperty -Path $regPath1 -Name $regName -ErrorAction Stop
        Write-Host "    [WARNING] Primary registry still has DisableCAD = $($verifyReg.$regName)" -ForegroundColor Yellow
        $restoreSuccess = $false
    } catch {
        Write-Host "    [VERIFIED] Primary registry: DisableCAD removed" -ForegroundColor Green
    }

    # Verify alternate registry cleaned
    try {
        $verifyReg2 = Get-ItemProperty -Path $regPath2 -Name $regName -ErrorAction Stop
        Write-Host "    [INFO] Alternate registry still has DisableCAD = $($verifyReg2.$regName)" -ForegroundColor Gray
    } catch {
        Write-Host "    [VERIFIED] Alternate registry: DisableCAD removed" -ForegroundColor Green
    }

    # -------------------------------------------------------------------------
    # FORCE GROUP POLICY UPDATE
    # -------------------------------------------------------------------------
    Write-Host "`n  Applying new domain Group Policies..." -ForegroundColor Cyan

    try {
        Write-Host "    Running gpupdate /force..." -ForegroundColor Gray
        $gpResult = gpupdate /force 2>&1
        Write-Host "    [OK] Group Policy update completed!" -ForegroundColor Green
        "Group Policy update completed successfully" | Out-File "C:\domain_migration_log.txt" -Append
    } catch {
        Write-Host "    [WARN] Group Policy update error: $_" -ForegroundColor Yellow
        "Group Policy update warning: $_" | Out-File "C:\domain_migration_log.txt" -Append
    }

    # -------------------------------------------------------------------------
    # SUMMARY
    # -------------------------------------------------------------------------
    if ($restoreSuccess -and $restoreErrors.Count -eq 0) {
        Write-Host "`n[SUCCESS] Default settings fully restored!" -ForegroundColor Green
        Write-Host "New domain policies will now fully apply.`n" -ForegroundColor Green
        "Settings restore: SUCCESS - all local overrides removed" | Out-File "C:\domain_migration_log.txt" -Append
    } elseif ($restoreErrors.Count -gt 0) {
        Write-Host "`n[WARNING] Settings restored with some warnings:" -ForegroundColor Yellow
        foreach ($err in $restoreErrors) {
            Write-Host "  - $err" -ForegroundColor Gray
        }
        Write-Host "New domain policies should still apply (warnings are non-critical)`n" -ForegroundColor Yellow
        "Settings restore: COMPLETED WITH WARNINGS" | Out-File "C:\domain_migration_log.txt" -Append
    }

    # =============================================================================
    # Cleanup and reboot
    # =============================================================================

    Write-Host "Computer will restart in 5 seconds..." -ForegroundColor Yellow

    # Log success
    "Domain join successful! $NEW_DOMAIN" | Out-File "C:\domain_migration_log.txt" -Append
    "Computer will restart in 5 seconds..." | Out-File "C:\domain_migration_log.txt" -Append

    # Cleanup scheduled tasks and registry flags
    Unregister-ScheduledTask -TaskName 'JoinNewDomainAfterReboot' -Confirm:$false -ErrorAction SilentlyContinue
    Remove-Item -Path "HKLM:\SOFTWARE\DomainMigrationCompleted" -Force -ErrorAction SilentlyContinue

    Start-Sleep -Seconds 5
    Restart-Computer -Force

}
catch {
    Write-Host "`n========================================" -ForegroundColor Red
    Write-Host "ERROR!" -ForegroundColor Red
    Write-Host "========================================`n" -ForegroundColor Red

    Write-Host "Failed to join domain: $_`n" -ForegroundColor Yellow

    # Log error
    "FATAL ERROR during domain join: $_" | Out-File "C:\domain_migration_log.txt" -Append

    # Detailed error log
    "========================================" | Out-File "C:\domain_migration_error.log" -Append
    "Domain join FAILED - $(Get-Date)" | Out-File "C:\domain_migration_error.log" -Append
    "========================================" | Out-File "C:\domain_migration_error.log" -Append
    "Domain: $NEW_DOMAIN" | Out-File "C:\domain_migration_error.log" -Append
    "Username: $NEW_DOMAIN_USER" | Out-File "C:\domain_migration_error.log" -Append
    "" | Out-File "C:\domain_migration_error.log" -Append
    "Error details:" | Out-File "C:\domain_migration_error.log" -Append
    $_ | Out-File "C:\domain_migration_error.log" -Append
    "" | Out-File "C:\domain_migration_error.log" -Append
    "Possible reasons:" | Out-File "C:\domain_migration_error.log" -Append
    "  1. Wrong credentials for $NEW_DOMAIN_USER" | Out-File "C:\domain_migration_error.log" -Append
    "  2. Cannot reach domain controller" | Out-File "C:\domain_migration_error.log" -Append
    "  3. DNS not configured for new domain" | Out-File "C:\domain_migration_error.log" -Append
    "  4. Network connectivity issues" | Out-File "C:\domain_migration_error.log" -Append
    "  5. LDAP/Kerberos ports blocked on DC" | Out-File "C:\domain_migration_error.log" -Append

    Write-Host "Possible reasons:" -ForegroundColor Yellow
    Write-Host "  1. Wrong credentials for $NEW_DOMAIN_USER" -ForegroundColor Gray
    Write-Host "  2. Cannot reach domain controller" -ForegroundColor Gray
    Write-Host "  3. DNS not configured for new domain" -ForegroundColor Gray
    Write-Host "  4. Network connectivity issues" -ForegroundColor Gray
    Write-Host "  5. LDAP/Kerberos ports blocked on DC`n" -ForegroundColor Gray

    Write-Host "Check:" -ForegroundColor Cyan
    Write-Host "  - ping $NEW_DOMAIN" -ForegroundColor Gray
    Write-Host "  - nslookup $NEW_DOMAIN" -ForegroundColor Gray
    Write-Host "  - C:\domain_migration_error.log for details`n" -ForegroundColor Gray

    # If running interactively - show pause, otherwise just exit
    if ([Environment]::UserInteractive) {
        pause
    }
    exit 1
}
